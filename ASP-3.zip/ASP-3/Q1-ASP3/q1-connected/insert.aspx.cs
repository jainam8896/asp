﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class insert : System.Web.UI.Page
{
    SqlConnection cn;
    SqlCommand cmd;
    SqlDataReader dr;
    string str;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            load_course();
        }
    }

    protected void load_course()
    {
        cn = new SqlConnection("Data Source=ML92\\SQLEXPRESS;Initial Catalog=student;User ID=sa;Password=sa123");
        cmd = new SqlCommand();
        cmd.Connection = cn;
        cmd.CommandType = CommandType.Text;
        str = "select * from course";
        try
        {
            cmd.CommandText = str;
            cn.Open();
            dr = cmd.ExecuteReader();
            courseList1.DataSource = dr;
            courseList1.DataTextField = "course_name";
            courseList1.DataValueField = "course_id";
            courseList1.DataBind();
        }
        catch (Exception ex)
        {
            Response.Write(ex.StackTrace);
        }
        finally
        {
            dr.Close();
            cmd.Dispose();
            cn.Dispose();
            cn.Close();
        }
    }

  

    protected void courseList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        cn = new SqlConnection("Data Source=ML92\\SQLEXPRESS;Initial Catalog=student;User ID=sa;Password=sa123");
        cmd = new SqlCommand();
        cmd.Connection = cn;
        cmd.CommandType = CommandType.Text;
        str = "select * from class where course_id IN (select course_id from course where course_id='" + courseList1.SelectedValue + "')";
        try
        {
            cmd.CommandText = str;
            cn.Open();
            dr = cmd.ExecuteReader();
            classList1.DataSource = dr;
            classList1.DataTextField = "class_name";
            classList1.DataValueField = "class_id";
            classList1.DataBind();
        }
        catch (Exception ex)
        {
            Response.Write(ex.StackTrace);
        }
        finally
        {
            dr.Close();
            cmd.Dispose();
            cn.Dispose();
            cn.Close();
        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        cn = new SqlConnection("Data Source=ML92\\SQLEXPRESS;Initial Catalog=student;User ID=sa;Password=sa123");
        cmd = new SqlCommand();
        cmd.Connection = cn;
        cmd.CommandType = CommandType.Text;
       
 
        str = "insert into student (ernollno,rollno,name,class_id,course_id,email,mobile,dob) values('"+ Convert.ToInt32(ernollno.Text) + "', '"+Convert.ToInt32(rollno.Text)+"','"+name.Text+"','"+classList1.SelectedValue+"','"+courseList1.SelectedValue+"','"+email.Text+"','"+Convert.ToInt64(mobile.Text)+"','"+Convert.ToDateTime(dob.Text).ToShortDateString()+"')";
        try
        {
            cmd.CommandText = str;
            cn.Open();
            cmd.ExecuteNonQuery();
           
        }
        catch (Exception ex)
        {
            Response.Write(ex.StackTrace);
        }
        finally
        {
           
            cmd.Dispose();
            cn.Dispose();
            cn.Close();
        }
    }

    protected void classList1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}