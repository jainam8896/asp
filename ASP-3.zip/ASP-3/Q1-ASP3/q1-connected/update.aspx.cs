﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class update : System.Web.UI.Page
{
    SqlConnection cn;
    SqlCommand cmd;
    SqlDataReader dr;
    string str;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {

        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        cn = new SqlConnection("Data Source=ML92\\SQLEXPRESS;Initial Catalog=student;User ID=sa;Password=sa123");
        cmd = new SqlCommand();
        cmd.Connection = cn;
        cmd.CommandType = CommandType.Text;
        str = "select email,mobile,dob from student where ernollno='"+Convert.ToInt32(ernollno.Text) + "'";
        try
        {
            cmd.CommandText = str;
            cn.Open();
            dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                email.Text = dr[0].ToString();
                mobile.Text = dr[1].ToString();
                dob.Text =  Convert.ToDateTime(dr[2]).ToString("yyyy-MM-dd");
            }
           
        }
        catch (Exception ex)
        {
            Response.Write(ex.StackTrace);
        }
        finally
        {
            dr.Close();
            cmd.Dispose();
            cn.Dispose();
            cn.Close();
        }
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        cn = new SqlConnection("Data Source=ML92\\SQLEXPRESS;Initial Catalog=student;User ID=sa;Password=sa123");
       
        str = "update student set email='" + email.Text + "' ,mobile='" + Convert.ToInt64(mobile.Text) + "',dob ='" + Convert.ToDateTime(dob.Text).ToString("yyyy-MM-dd") + "' where ernollno='" + Convert.ToInt32(ernollno.Text) + "'";
        cmd = new SqlCommand(str,cn);
        cmd.CommandType = CommandType.Text;
        try
        {
           
            cn.Open();
            cmd.ExecuteNonQuery();

        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {

            cmd.Dispose();
            cn.Dispose();
            ernollno.Text = "";
            email.Text = "";
            mobile.Text = "";
            dob.Text = "";

        }
    }
}