﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class duplicate : System.Web.UI.Page
{
    SqlConnection cn;
    SqlCommand cmd;
    SqlDataReader rd;
    string str;
    
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            DropDownList1.Visible = false;
            Label2.Visible=false;
        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        cn = new SqlConnection("Data Source=ML92\\SQLEXPRESS;Initial Catalog=student;User ID=sa;Password=sa123");
        str = "select * from student where UPPER(name) like '" + name.Text + "%'";
        cmd = new SqlCommand(str,cn);
       
        cmd.CommandType = CommandType.Text;
        try
        {
            cn.Open();
            rd = cmd.ExecuteReader();
            int cnt = 0;
            if (rd.HasRows)
            {
                while (rd.Read())
                {
                    cnt++;
                }
            }
            rd.Close();
            if(cnt == 1)
            {
                DropDownList1.Visible = false;
                Label2.Visible = false;
                rd = cmd.ExecuteReader();
                GridView1.DataSource = rd;
                GridView1.DataBind();
            }
            else if(cnt > 2)
            {
                DropDownList1.Visible = true;
                Label2.Visible = true;
                string strCourse = "select course_id,course_name from course where course_id in (select course_id from student where UPPER(name) like '"+name.Text+"%')";
                cmd = new SqlCommand(strCourse, cn);
                rd = cmd.ExecuteReader();
                
                DropDownList1.DataSource = rd;
                DropDownList1.DataTextField = "course_name";
                DropDownList1.DataValueField = "course_id";
                DropDownList1.DataBind();
            }
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {
            cn.Close();
            rd.Close();
            cmd.Dispose();
        }
    }

    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        str = "select * from student where course_id='" + Convert.ToInt32(DropDownList1.SelectedValue) + "' and UPPER(name) like'" + name.Text.ToUpper() + "%'";
        cn = new SqlConnection("Data Source=ML92\\SQLEXPRESS;Initial Catalog=student;User ID=sa;Password=sa123");
        cmd = new SqlCommand(str, cn);
        cmd.CommandType = CommandType.Text;
        try
        {
            cn.Open();
            rd = cmd.ExecuteReader();
            GridView1.DataSource = rd;
            GridView1.DataBind();

        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {
            cmd.Dispose();
            rd.Close();
            cn.Close();
        }
    }
}