﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class delete : System.Web.UI.Page
{
    SqlConnection cn;
    SqlCommand cmd;
    SqlDataReader dr;
    string str;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            load_course();
        }
    }

    protected void load_course()
    {
        cn = new SqlConnection("Data Source=ML92\\SQLEXPRESS;Initial Catalog=student;User ID=sa;Password=sa123");
        cmd = new SqlCommand();
        cmd.Connection = cn;
        cmd.CommandType = CommandType.Text;
        str = "select * from course";
        try
        {
            cmd.CommandText = str;
            cn.Open();
            dr = cmd.ExecuteReader();
            courseList1.DataSource = dr;
            courseList1.DataTextField = "course_name";
            courseList1.DataValueField = "course_id";
            courseList1.DataBind();
        }
        catch (Exception ex)
        {
            Response.Write(ex.StackTrace);
        }
        finally
        {
            dr.Close();
            cmd.Dispose();
            cn.Dispose();
            cn.Close();
        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        cn = new SqlConnection("Data Source=ML92\\SQLEXPRESS;Initial Catalog=student;User ID=sa;Password=sa123");
        cmd = new SqlCommand();
        cmd.Connection = cn;
        cmd.CommandType = CommandType.Text;
        str = "delete from student where course_id='" + courseList1.SelectedValue + "' ANd rollno='" + Convert.ToInt32(rollno.Text) + "'";
        try
        {
            cmd.CommandText = str;
            cn.Open();
            cmd.ExecuteNonQuery();

        }
        catch (Exception ex)
        {
            Response.Write(ex.StackTrace);
        }
        finally
        {
            cmd.Dispose();
            cn.Dispose();
            cn.Close();
        }
    }
}