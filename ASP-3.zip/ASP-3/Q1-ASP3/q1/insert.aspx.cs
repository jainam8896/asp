﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class insert : System.Web.UI.Page
{
    SqlDataAdapter da;
    DataSet ds;
    string str;
    SqlCommandBuilder cb;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            load_course();
        }
    }

    protected void load_course()
    {
        str = "select * from course";
        da = new SqlDataAdapter(str, "Data Source=ML92\\SQLEXPRESS;Initial Catalog=student;User ID=sa;Password=sa123");
        ds = new DataSet();
        da.Fill(ds);
        courseList1.DataSource = ds;
        courseList1.DataTextField = "course_name";
        courseList1.DataValueField = "course_id";
        courseList1.DataBind();
    }

  

    protected void courseList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        str = "select * from class where course_id IN (select course_id from course where course_id = '" + courseList1.SelectedValue + "')";

        da = new SqlDataAdapter(str, "Data Source=ML92\\SQLEXPRESS;Initial Catalog=student;User ID=sa;Password=sa123");
        ds = new DataSet();
        da.Fill(ds);
        classList1.DataSource = ds;
        classList1.DataTextField = "class_name";
        classList1.DataValueField = "class_id";
        classList1.DataBind();
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        str = "select * from student";
        da = new SqlDataAdapter(str, "Data Source=ML92\\SQLEXPRESS;Initial Catalog=student;User ID=sa;Password=sa123");
        ds = new DataSet();
        cb = new SqlCommandBuilder(da);
        da.InsertCommand = cb.GetInsertCommand();
        da.Fill(ds);
        try
        {
            DataRow dr = ds.Tables[0].NewRow();
            dr[0] =Convert.ToInt32(ernollno.Text);
            
            dr[1] = Convert.ToInt32(rollno.Text);
          
            dr[2] = name.Text;
            dr[3] = classList1.SelectedValue;
           
            dr[4] =courseList1.SelectedValue;
            
            dr[5] = email.Text;
            dr[6] = Convert.ToInt64(mobile.Text);

            dr[7] = Convert.ToDateTime(dob.Text).ToShortDateString();

            ds.Tables[0].Rows.Add(dr);
            da.Update(ds);

        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {
            cb.Dispose();
            ds.Dispose();
            da.Dispose();
            ernollno.Text = "";
            rollno.Text = "";
            name.Text = "";
            email.Text = "";
            mobile.Text = "";
            dob.Text = "";
        }
    }

    protected void classList1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}