﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class dob : System.Web.UI.Page
{
    SqlDataAdapter da;
    DataSet ds;
    string str;
    SqlCommandBuilder cb;
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        str = "select ernollno,rollno,name,email,dob from student where YEAR(dob)='"+Convert.ToInt32(year.Text)+"'";
        da = new SqlDataAdapter(str, "Data Source=ML92\\SQLEXPRESS;Initial Catalog=student;User ID=sa;Password=sa123");
        ds = new DataSet();
        try
        {
            da.Fill(ds);
            GridView1.DataSource = ds;
            GridView1.DataBind();

        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {
            da.Dispose();
            ds.Dispose();
        }
    }
}