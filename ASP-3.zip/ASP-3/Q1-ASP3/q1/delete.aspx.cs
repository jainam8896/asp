﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class delete : System.Web.UI.Page
{
    SqlDataAdapter da;
    DataSet ds;
    string str;
    SqlCommandBuilder cb;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            load_course();
        }
    }

    protected void load_course()
    {
        str = "select * from course";
        da = new SqlDataAdapter(str, "Data Source=ML92\\SQLEXPRESS;Initial Catalog=student;User ID=sa;Password=sa123");
        ds = new DataSet();
        da.Fill(ds);
        courseList1.DataSource = ds;
        courseList1.DataTextField = "course_name";
        courseList1.DataValueField = "course_id";
        courseList1.DataBind();
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        str = "select * from student where course_id='"+courseList1.SelectedValue+"' ANd rollno='"+Convert.ToInt32(rollno.Text)+"'";
        da = new SqlDataAdapter(str, "Data Source=ML92\\SQLEXPRESS;Initial Catalog=student;User ID=sa;Password=sa123");

        ds = new DataSet();
        cb = new SqlCommandBuilder(da);
        da.DeleteCommand = cb.GetDeleteCommand();
        da.Fill(ds);
       try
        {
            DataRow dr = ds.Tables[0].Rows[0];
            if (ds.Tables[0].Rows.Count > 0)
            {
                dr.Delete();
            }
            else
            {
                Response.Write("No Record Found");
            }
            da.Update(ds);
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {
            cb.Dispose();
            ds.Dispose();
            da.Dispose();
            rollno.Text = "";                   
        }
    }
}