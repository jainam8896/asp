﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class update : System.Web.UI.Page
{
    SqlDataAdapter da;
    DataSet ds;
    string str;
    SqlCommandBuilder cb;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {

        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        str = "select email,mobile,dob from student where ernollno='"+Convert.ToInt32(ernollno.Text) +"'";
        da = new SqlDataAdapter(str, "Data Source=ML92\\SQLEXPRESS;Initial Catalog=student;User ID=sa;Password=sa123");
        ds = new DataSet();
        da.Fill(ds);

        int no = Convert.ToInt32(ernollno.Text);
        if (ds.Tables[0].Rows.Count > 0)
        {
            email.Text = ds.Tables[0].Rows[0].ItemArray[0].ToString();
            mobile.Text = Convert.ToInt64(ds.Tables[0].Rows[0].ItemArray[1].ToString()).ToString();
            dob.Text = Convert.ToDateTime(ds.Tables[0].Rows[0].ItemArray[2]).ToString("yyyy-MM-dd");
        }
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        str = "select * from student where ernollno='" + Convert.ToInt32(ernollno.Text) + "'";
        da = new SqlDataAdapter(str, "Data Source=ML92\\SQLEXPRESS;Initial Catalog=student;User ID=sa;Password=sa123");
        ds = new DataSet();
        cb = new SqlCommandBuilder(da);
        da.UpdateCommand = cb.GetUpdateCommand();
        da.Fill(ds);
        try
        {
            DataRow dr = ds.Tables[0].Rows[0];   
            dr[5] = email.Text;
            dr[6] = Convert.ToInt64(mobile.Text);
            dr[7] = Convert.ToDateTime(dob.Text).ToShortDateString();
           
            da.Update(ds);

        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {
            cb.Dispose();
            ds.Dispose();
            da.Dispose();
            ernollno.Text = "";
            email.Text = "";
            mobile.Text = "";
            dob.Text = "";
        }
    }
}