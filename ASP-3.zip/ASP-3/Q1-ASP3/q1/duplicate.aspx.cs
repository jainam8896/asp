﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class duplicate : System.Web.UI.Page
{
    SqlDataAdapter da;
    DataSet ds;
    string str;
    SqlCommandBuilder cb;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            DropDownList1.Visible = false;
            Label2.Visible=false;
        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        str = "select * from student where UPPER(name) like '" + name.Text + "%'";
        da = new SqlDataAdapter(str, "Data Source=ML92\\SQLEXPRESS;Initial Catalog=student;User ID=sa;Password=sa123");
        ds = new DataSet();
        try
        {
            da.Fill(ds);
            int cnt = ds.Tables[0].Rows.Count;
            if (cnt == 1)
            {
                GridView1.DataSource = ds;
                GridView1.DataBind();
            }
            else
            {
                DropDownList1.Visible = true;
                Label2.Visible = true;
                string strCourse = "select course_id,course_name from course where course_id in (select course_id from student where UPPER(name) like '"+name.Text+"%')";
                da = new SqlDataAdapter(strCourse, "Data Source=ML92\\SQLEXPRESS;Initial Catalog=student;User ID=sa;Password=sa123");
                ds = new DataSet();
                da.Fill(ds);
                DropDownList1.DataSource = ds;
                DropDownList1.DataTextField = "course_name";
                DropDownList1.DataValueField = "course_id";
                DropDownList1.DataBind();
            }
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {
            da.Dispose();
            ds.Dispose();
        }
    }

    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        str = "select * from student where course_id='" + Convert.ToInt32(DropDownList1.SelectedValue) + "' and UPPER(name) like'" + name.Text.ToUpper() + "%'";
        da = new SqlDataAdapter(str, "Data Source=ML92\\SQLEXPRESS;Initial Catalog=student;User ID=sa;Password=sa123");
        ds = new DataSet();
        try
        {
            da.Fill(ds);
            GridView1.DataSource = ds;
            GridView1.DataBind();

        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {
            da.Dispose();
            ds.Dispose();
        }
    }
}