﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class display : System.Web.UI.Page
{
    SqlDataAdapter da;
    DataSet ds;
    SqlCommandBuilder cmdb;
    string str;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Load_data();
        }
    }

    protected void Load_data()
    {
        
    }
}