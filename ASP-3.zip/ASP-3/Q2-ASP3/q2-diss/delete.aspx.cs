﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class delete : System.Web.UI.Page
{
    SqlDataAdapter da;
    DataSet ds;
    SqlCommandBuilder cmdb;
    string str;
    string conn = "Data Source=DESKTOP-46VOVC3;Initial Catalog=myemp;User ID=sa;Password=sa123";
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Delete_Click(object sender, EventArgs e)
    {
        try
        {
            str = "select * from emp";
            da = new SqlDataAdapter(str,conn);
            ds = new DataSet();
            da.Fill(ds);
            cmdb = new SqlCommandBuilder(da);
            da.DeleteCommand = cmdb.GetDeleteCommand();
            int age = Convert.ToInt16(ageDelete.Text);
            DateTime cur = DateTime.Now.AddYears(-age);
            //Response.Write("<script>alert('" + cur + "')</script>");
            foreach(DataRow dr in ds.Tables[0].Rows)
            {
                if (Convert.ToDateTime(dr["dob"]) < cur)
                {
                    dr.Delete();
                    break;
                }
            }
            int ans = da.Update(ds);
            if (ans > 0)
            {
                Response.Write("<script>alert('Records Has Been Deleted...')</script>");
                ageDelete.Text = "";
            }
            else
            {
                Response.Write("<script>alert('No Record Founds...')</script>");
                ageDelete.Text = "";
            }
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {
            da.Dispose();
            ds.Dispose();
            cmdb.Dispose();
        }
    }
}