﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class insert : System.Web.UI.Page
{
    SqlDataAdapter da;
    DataSet ds;
    string str;
    SqlCommandBuilder cmdb;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            load_dept();
            load_desg();
        }
    }

    protected void load_dept()
    {
        str = "select * from dept";
        da = new SqlDataAdapter(str, "Data Source=DESKTOP-46VOVC3;Initial Catalog=myemp;User ID=sa;Password=sa123");
        ds = new DataSet();
        try
        {
            da.Fill(ds);
            dept.DataSource = ds;
            dept.DataValueField = "dept_id";
            dept.DataTextField = "dept_name";
            dept.DataBind();
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {
            da.Dispose();
            ds.Dispose();
        }
    }

    protected void Insert_Click(object sender, EventArgs e)
    {
        string newName, ext;
        str = "select * from emp";
        da = new SqlDataAdapter(str, "Data Source=DESKTOP-46VOVC3;Initial Catalog=myemp;User ID=sa;Password=sa123");
        ds = new DataSet();
        cmdb = new SqlCommandBuilder(da);
        try
        {
            da.InsertCommand = cmdb.GetInsertCommand();
            da.Fill(ds);
            DataRow dr;
            dr = ds.Tables[0].NewRow();
           
            dr[1] = name.Text;
            dr[2] = Convert.ToDateTime(dob.Text).ToShortDateString();
            dr[3] = dept.SelectedValue;
            dr[4] = desg.SelectedValue;
            dr[5] = salary.Text;
            if (cv.HasFile)
            {
                string getExt = System.IO.Path.GetExtension(cv.FileName);
                if (getExt.Equals(".pdf"))
                {
                    Random rm = new Random();
                    int random = rm.Next(1, 1000);
                    ext = System.IO.Path.GetExtension(cv.FileName);
                    newName = "NB-cv" + random + ".pdf" ;
                    cv.SaveAs(Server.MapPath("./images") + "/" + newName);
                   
                    dr[6] = newName;
                   
                }else
                {
                    Response.Write("upload only pdf file");
                }
            }
            ds.Tables[0].Rows.Add(dr);
            da.Update(ds);

        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {
            cmdb.Dispose();
            da.Dispose();
            ds.Dispose();
        }
    }

    protected void dept_SelectedIndexChanged(object sender, EventArgs e)
    {
       
    }

    protected void load_desg()
    {
        str = "select * from desg";
        da = new SqlDataAdapter(str, "Data Source=DESKTOP-46VOVC3;Initial Catalog=myemp;User ID=sa;Password=sa123");
        ds = new DataSet();
        try
        {
            da.Fill(ds);
            desg.DataSource = ds;
            desg.DataValueField = "desg_id";
            desg.DataTextField = "desg_name";
            desg.DataBind();
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {
            da.Dispose();
            ds.Dispose();
        }
    }
}