﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class search : System.Web.UI.Page
{
    SqlDataAdapter da;
    DataSet ds;
    string str;
    SqlCommandBuilder cmdb;
    string conn = "Data Source=DESKTOP-46VOVC3;Initial Catalog=myemp;User ID=sa;Password=sa123";
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void SearchBtn_Click(object sender, EventArgs e)
    {
        string searchCriteria = ss.Text.Trim();
        str = "select * from emp where desg_id = '"+searchCriteria+"' or salary > '"+searchCriteria+"'";
        da = new SqlDataAdapter(str, conn);
        ds = new DataSet();
        try
        {
            da.Fill(ds);
            GridView1.DataSource = ds;
            GridView1.DataBind();
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {
            da.Dispose();
            ds.Dispose();
        }
    }
}