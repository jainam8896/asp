﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class update : System.Web.UI.Page
{
    SqlDataAdapter da;
    DataSet ds;
    string str;
    SqlCommandBuilder cmdb;
    string conn = "Data Source=DESKTOP-46VOVC3;Initial Catalog=myemp;User ID=sa;Password=sa123";

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Label1.Visible = false;
            Label2.Visible = false;
            Label3.Visible = false;
            dept.Visible = false;
            desg.Visible = false;
            salary.Visible = false;
            UpdateBtn.Visible = false;
            DesgData();
            DeptData();
        }
    }

    protected void DeptData()
    {
        str = "select * from dept";
        da = new SqlDataAdapter(str, "Data Source=DESKTOP-46VOVC3;Initial Catalog=myemp;User ID=sa;Password=sa123");
        ds = new DataSet();
        try
        {
            da.Fill(ds);
            dept.DataSource = ds;
            dept.DataValueField = "dept_id";
            dept.DataTextField = "dept_name";
            dept.DataBind();
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {
            da.Dispose();
            ds.Dispose();
        }
    }

    protected void DesgData()
    {
        str = "select * from desg";
        da = new SqlDataAdapter(str, "Data Source=DESKTOP-46VOVC3;Initial Catalog=myemp;User ID=sa;Password=sa123");
        ds = new DataSet();
        try
        {
            da.Fill(ds);
            desg.DataSource = ds;
            desg.DataValueField = "desg_id";
            desg.DataTextField = "desg_name";
            desg.DataBind();
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {
            da.Dispose();
            ds.Dispose();
        }
    }

    protected void SearchBtn_Click(object sender, EventArgs e)
    {
        try
        {
            Label1.Visible = true;
            Label2.Visible = true;
            Label3.Visible = true;
            dept.Visible = true;
            desg.Visible = true;
            salary.Visible = true;
            UpdateBtn.Visible = true;
            str = "SELECT E.eno,E.name,D.dept_name,DS.desg_name,E.salary FROM emp AS E INNER JOIN dept AS D ON E.dept_id = D.dept_id INNER JOIN desg AS DS ON E.desg_id = DS.desg_id WHERE E.eno ='" + eno.Text.ToString() + "'; ";
            da = new SqlDataAdapter(str, conn);
            ds = new DataSet();
            da.Fill(ds);
            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                if (Convert.ToInt32(dr["eno"]) == Convert.ToInt32(eno.Text))
                {

                    dr["dept_name"] = dept.SelectedItem.Value;
                    dr["desg_name"] = desg.SelectedItem.Value;
                    salary.Text = dr["salary"].ToString();
                    break;
                }
            }
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {
            da.Dispose();
            ds.Dispose();
        }
    }

    protected void UpdateBtn_Click(object sender, EventArgs e)
    {
        try
        {
           
            str = "select * from emp";
            da = new SqlDataAdapter(str, conn);
            ds = new DataSet();
            da.Fill(ds);
            cmdb = new SqlCommandBuilder(da);
            da.UpdateCommand = cmdb.GetUpdateCommand();
            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                if (Convert.ToInt32(dr["eno"]) == Convert.ToInt32(eno.Text))
                {

                    dr["dept_id"] = dept.SelectedValue;
                    dr["desg_id"] = desg.SelectedValue;
                    dr["salary"] = salary.Text;
                    break;
                }
            }
            da.Update(ds);
            Label1.Visible = false;
            Label2.Visible = false;
            Label3.Visible = false;
            dept.Visible = false;
            desg.Visible = false;
            salary.Visible = false;
            UpdateBtn.Visible = false;

        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {
            da.Dispose();
            ds.Dispose();
            cmdb.Dispose();
        }
    }

    protected void dept_SelectedIndexChanged(object sender, EventArgs e)
    {
    }
}