﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class delete : System.Web.UI.Page
{
    SqlConnection cn;
    SqlCommand cmd;
    SqlDataReader dr;
    string str; 
    string conn = "Data Source=DESKTOP-46VOVC3;Initial Catalog=myemp;User ID=sa;Password=sa123";
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Delete_Click(object sender, EventArgs e)
    {
        try
        {
            cn = new SqlConnection(conn);
            str = "delete from emp where DATEDIFF(YEAR,dob,CURRENT_TIMESTAMP) > 58";
            cmd = new SqlCommand(str, cn);
            cn.Open();
            cmd.ExecuteNonQuery();
            cn.Close();
            cn.Dispose();
            cmd.Dispose();

        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {
            
        }
    }
}