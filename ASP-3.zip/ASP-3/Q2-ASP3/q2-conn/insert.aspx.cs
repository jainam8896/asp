﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class insert : System.Web.UI.Page
{
    SqlConnection cn;
    SqlCommand cmd;
    SqlDataReader dr;
    string str;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            load_dept(); 
            load_desg();
        }
    }

    protected void load_dept()
    {
        cn = new SqlConnection("Data Source=DESKTOP-46VOVC3;Initial Catalog=myemp;User ID=sa;Password=sa123");
        cmd = new SqlCommand();
        cmd.Connection = cn;
        cmd.CommandType = CommandType.Text;
        str = "select * from dept";
        try
        {
            cmd.CommandText = str;
            cn.Open();
            dr = cmd.ExecuteReader();
            dept.DataSource = dr;
            dept.DataValueField = "dept_id";
            dept.DataTextField = "dept_name";
            dept.DataBind();
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {
            dr.Dispose();
            cmd.Dispose();
            cn.Close();
            cn.Dispose();
        }
    }

    protected void load_desg()
    {
        cn = new SqlConnection("Data Source=DESKTOP-46VOVC3;Initial Catalog=myemp;User ID=sa;Password=sa123");
        cmd = new SqlCommand();
        cmd.Connection = cn;
        cmd.CommandType = CommandType.Text;
        str = "select * from desg";
        try
        {
            cmd.CommandText = str;
            cn.Open();
            dr = cmd.ExecuteReader();
            desg.DataSource = dr;
            desg.DataValueField = "desg_id";
            desg.DataTextField = "desg_name";
            desg.DataBind();
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {
            dr.Dispose();
            cmd.Dispose();
            cn.Close();
            cn.Dispose();
        }
    }

    protected void Insert_Click(object sender, EventArgs e)
    {
        string newName, ext;
        cn = new SqlConnection("Data Source=DESKTOP-46VOVC3;Initial Catalog=myemp;User ID=sa;Password=sa123");
        cmd = new SqlCommand();
        cmd.Connection = cn;
        cmd.CommandType = CommandType.Text;
        try
        {
            
            if (cv.HasFile)
            {
                string getExt = System.IO.Path.GetExtension(cv.FileName);
                if (getExt.Equals(".pdf"))
                {
                    Random rm = new Random();
                    int random = rm.Next(1, 1000);
                    ext = System.IO.Path.GetExtension(cv.FileName);
                    newName = "NB-cv" + random + ".pdf" ;
                    cv.SaveAs(Server.MapPath("./images") + "/" + newName);

                    str = "insert into emp(name,dob,dept_id,desg_id,salary,cv) values('"+name.Text+"','"+ Convert.ToDateTime(dob.Text).ToString("yyyy-MM-dd") + "','"+Convert.ToInt32(dept.SelectedValue)+ "','" + Convert.ToInt32(desg.SelectedValue) + "','" + Convert.ToInt64(salary.Text) + "','" + newName + "')";
                   
                }else
                {
                    Response.Write("upload only pdf file");
                }
                cmd.CommandText = str;
                cn.Open();
                cmd.ExecuteNonQuery();
            }
          

        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {
            cmd.Dispose();
            cn.Dispose();
            cn.Close();
        }
    }

   

   
}