﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class search : System.Web.UI.Page
{
    SqlConnection cn;
    SqlDataReader dr;
    SqlCommand cmd;

    string str, conn = "Data Source=DESKTOP-46VOVC3;Initial Catalog=myemp;User ID=sa;Password=sa123";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
                
            
        }
    }

    protected void SearchBtn_Click(object sender, EventArgs e)
    {
        string searchCriteria = ss.Text.Trim();
        cn = new SqlConnection(conn);
       
        str = "select * from emp where desg_id = '" + searchCriteria + "' or salary > '" + searchCriteria + "'";
        cmd = new SqlCommand(str, cn);
        cmd.CommandType = CommandType.Text;
        cn.Open();
        try
        {
            dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                GridView1.DataSource = dr;
                GridView1.DataBind();
            }else
            {
                GridView1.Visible = false;  
            }
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {
          
            cn.Dispose();
            cmd.Dispose();
            cn.Close();
        }
    }
}