﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class update : System.Web.UI.Page
{
    SqlConnection cn;
    SqlCommand cmd;
    SqlDataReader dr;
    string str;
    string conn = "Data Source=DESKTOP-46VOVC3;Initial Catalog=myemp;User ID=sa;Password=sa123";

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Label1.Visible = false;
            Label2.Visible = false;
            Label3.Visible = false;
            dept.Visible = false;
            desg.Visible = false;
            salary.Visible = false;
            UpdateBtn.Visible = false;
            DesgData();
            DeptData();
        }
    }

    protected void DeptData()
    {
        cn = new SqlConnection("Data Source=DESKTOP-46VOVC3;Initial Catalog=myemp;User ID=sa;Password=sa123");
        cmd = new SqlCommand();
        cmd.Connection = cn;
        cmd.CommandType = CommandType.Text;
        str = "select * from dept";
        try
        {
            cmd.CommandText = str;
            cn.Open();
            dr = cmd.ExecuteReader();
            dept.DataSource = dr;
            dept.DataValueField = "dept_id";
            dept.DataTextField = "dept_name";
            dept.DataBind();
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {
            dr.Dispose();
            cmd.Dispose();
            cn.Close();
            cn.Dispose();
        }
    }

    protected void DesgData()
    {
        cn = new SqlConnection("Data Source=DESKTOP-46VOVC3;Initial Catalog=myemp;User ID=sa;Password=sa123");
        cmd = new SqlCommand();
        cmd.Connection = cn;
        cmd.CommandType = CommandType.Text;
        str = "select * from desg";
        try
        {
            cmd.CommandText = str;
            cn.Open();
            dr = cmd.ExecuteReader();
            desg.DataSource = dr;
            desg.DataValueField = "desg_id";
            desg.DataTextField = "desg_name";
            desg.DataBind();
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {
            dr.Dispose();
            cmd.Dispose();
            cn.Close();
            cn.Dispose();
        }
    }

    protected void SearchBtn_Click(object sender, EventArgs e)
    {
        try
        {
            Label1.Visible = true;
            Label2.Visible = true;
            Label3.Visible = true;
            dept.Visible = true;
            desg.Visible = true;
            salary.Visible = true;
            UpdateBtn.Visible = true;
            cn = new SqlConnection("Data Source=DESKTOP-46VOVC3;Initial Catalog=myemp;User ID=sa;Password=sa123");
            cmd = new SqlCommand();
            cmd.Connection = cn;
            cmd.CommandType = CommandType.Text;
            str = "select dept_id,desg_id,salary from emp where eno='"+Convert.ToInt32(eno.Text)+"'";
            cmd.CommandText = str;
            cn.Open();
            dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                dept.SelectedValue = dr[0].ToString();
                desg.SelectedValue = dr[1].ToString();
                salary.Text = dr[2].ToString();
            }
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {
            dr.Dispose();
            cmd.Dispose();
            cn.Close();
            cn.Dispose();
        }
    }

    protected void UpdateBtn_Click(object sender, EventArgs e)
    {
        try
        {
            cn = new SqlConnection("Data Source=DESKTOP-46VOVC3;Initial Catalog=myemp;User ID=sa;Password=sa123");
            cmd = new SqlCommand();
            cmd.Connection = cn;
            cmd.CommandType = CommandType.Text;
            str = "update emp set dept_id='"+Convert.ToInt32(dept.SelectedValue)+ "',desg_id='" + Convert.ToInt32(desg.SelectedValue) + "',salary='" + Convert.ToInt32(salary.Text) + "' where eno='"+Convert.ToInt32(eno.Text)+"'";
            cmd.CommandText = str;
            cn.Open();
            dr = cmd.ExecuteReader();

            Label1.Visible = false;
            Label2.Visible = false;
            Label3.Visible = false;
            dept.Visible = false;
            desg.Visible = false;
            salary.Visible = false;
            UpdateBtn.Visible = false;

        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {          
            cmd.Dispose();
            cn.Close();
        }
    }

    protected void dept_SelectedIndexChanged(object sender, EventArgs e)
    {
    }
}